// <div class ="card" >
//     <img src="Images/cat1.jpg" alt = "Memory Logo" width = "150px" height = "150px" >
//         </div>
function shuffle(_array) {
    var currentIndex = _array.length; //2. das array it 16 karten, er nimmt die länge davon und erstelllt leere variable - randomIndex
    var randomIndex;
    // While there remain elements to shuffle...
    while (0 !== currentIndex) {
        // Pick a remaining element...
        randomIndex = Math.floor(Math.random() * currentIndex); //erstellt randomindex zahl zwischen 1 und 16 und fängt mit 16 an. 
        currentIndex--; //reduziert es um 1, sonst wär while scheife unendlich
        // And swap it with the current element. array wird durchgegangen von 0, 1, 2.. und diese werden mit random zahlen ersetzt.
        _a = [
            _array[randomIndex], _array[currentIndex]
        ], _array[currentIndex] = _a[0], _array[randomIndex] = _a[1];
    }
    return _array;
    var _a;
}
document.addEventListener("DOMContentLoaded", function (event) {
    var cardStorage = document.getElementById("cardStorage");
    var allCards = new Array(); //leeres Array wo alle karten sein werden
    for (var i = 0; i < 8; i++) {
        for (var index = 0; index < 2; index++) {
            var card = document.createElement("div"); //ein div eine karte
            card.classList.add("cards"); //div mit der kalsse cards
            card.classList.add("turnAround");
            card.classList.add("pair_" + i); //jede karte wir kenntlcih gemacht welche zsm gehören.
            allCards.push(card); //erstellte element Card (8stück) werden in allCards gespeichert.
        }
    }
    allCards = shuffle(allCards);
    for (var i2 = 0; i2 < allCards.length; i2++) {
        cardStorage.appendChild(allCards[i2]); //alle 16 karten werden dem cardstorage hinzugefügt
    }
    //Neuer Abschnitt: Karten anclicken
    var selectedCard = document.getElementsByClassName("cards");
    var firstCard;
    var secondCard;
    var clickCount = 0;
    for (var cardNum = 0; cardNum < selectedCard.length; cardNum++) {
        selectedCard[cardNum].addEventListener("click", selectCard);
    }
    function selectCard(_e) {
        if (clickCount == 2) {
            firstCard = undefined;
            secondCard = undefined;
            var turnedCards = document.getElementsByClassName("turnForward");
            console.log(turnedCards);
            for (var turned = 0; turned < turnedCards.length; turned++) {
                turnedCards[turned].classList.remove("turnForward");
                turnedCards[turned].classList.add("turnAround");
            }
            clickCount = 0;
        }
        this.classList.remove("turnAround");
        this.classList.add("turnForward");
        if (!secondCard && !firstCard) {
            firstCard = this.classList.item(1);
            console.log(firstCard);
        }
        else if (firstCard && !secondCard) {
            secondCard = this.classList.item(1);
            console.log(secondCard);
        }
        if (firstCard == secondCard) {
            console.log("Hurrah");
            firstCard = undefined;
            secondCard = undefined;
        }
        clickCount++;
    }
});
