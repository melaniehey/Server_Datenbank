namespace Prüfungsaufgabe {
    let canvas: HTMLCanvasElement = <HTMLCanvasElement>document.getElementById("myCanvas");
    let context: CanvasRenderingContext2D = canvas.getContext("2d");

    //Background
    // context.fillStyle = "lightblue";
    // context.fillRect(0, 0, 500, 300); //X-Koordin, Y-Koordin, Breite, Höhe
    // context.fillStyle = "lightgreen";
    // context.fillRect(0, 300, 500, 200);
}